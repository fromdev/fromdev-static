These icons are provided by http://www.fromdev.com 
to download visit : http://www.fromdev.com/2013/09/Premium-Social-Icons-Free-Download.html

